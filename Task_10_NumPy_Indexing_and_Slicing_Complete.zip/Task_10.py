import numpy as np

# Task 10: NumPy Indexing and Slicing

arr = np.array([10, 20, 30, 40, 50, 60])
print("Array:", arr)
print("First element:", arr[0])
print("Third element:", arr[2])
print("Last element:", arr[-1])
print("Second last element:", arr[-2])

matrix = np.array([[10, 20, 30],
                   [40, 50, 60],
                   [70, 80, 90]])
print("\nMatrix:\n", matrix)
print("Element at row 1, column 2:", matrix[1, 2])
print("First row:", matrix[0, :])
print("Second column:", matrix[:, 1])
print("Last row:", matrix[-1, :])

print("\nSlicing examples")
print("First three:", arr[:3])
print("Index 2 to 4:", arr[2:5])
print("Every second:", arr[::2])
print("Reverse:", arr[::-1])
print("Last three:", arr[-3:])

print("\n2D slicing")
print("First two rows:\n", matrix[:2, :])
print("Last two columns:\n", matrix[:, 1:])
print("Selected block:\n", matrix[1:3, 1:3])

marks = np.array([[78, 82, 91],
                  [65, 74, 80],
                  [88, 90, 95],
                  [55, 68, 72]])
print("\nStudent marks:\n", marks)
print("First student:", marks[0, :])
print("Second subject:", marks[:, 1])
print("Top two students:\n", marks[:2, :])
print("Last two students:\n", marks[-2:, :])
print("Marks above 80:", marks[marks > 80])
